#!/usr/bin/env python3
"""Exact pixel-boundary conversion; verify serialized TTF and WOFF2, not just input."""
import argparse
from collections import defaultdict
from html import escape
import json
from pathlib import Path

from fontTools.fontBuilder import FontBuilder
from fontTools.pens.ttGlyphPen import TTGlyphPen
from fontTools.ttLib import TTFont, newTable

COMMIT = "afec9e5282d09697d542f5de1e11072206afd1db"
PIXEL = 64
COPYRIGHT = "Copyright(c) 2022-2025 vice contributors"
LICENSE = "GPL-3.0-only. Converted from Vice's STARS bitmaps by ATC-SIM; modified 2026-10-08."
# Vice's stars.go identifies 0x80 as delta and 0x1e as filled up triangle.
# Every source index also has a stable PUA alias; no invented symbol semantics.
ALIASES = {0x0394: 0x80, 0x2206: 0x80, 0x25B2: 0x1E, 0x25BC: 0x1F, 0x25A1: 0x81, 0x00A0: 32}


def cells(g):
    w, h = g["Bounds"]
    ox, oy = g["Offset"]
    assert 0 <= w <= 32 and h >= 0 and len(g["Bitmap"]) == h, "invalid bitmap dimensions"
    assert g["StepX"] >= 0
    return {(ox + x, oy + h - y - 1)
            for y, row in enumerate(g["Bitmap"])
            for x in range(w) if row & (1 << (31 - x))}


def boundary(occupied):
    edges = set()
    for x, y in occupied:
        p = [(x, y), (x, y + 1), (x + 1, y + 1), (x + 1, y)]
        for a, b in zip(p, p[1:] + p[:1]):
            if (b, a) in edges:
                edges.remove((b, a))
            else:
                assert (a, b) not in edges
                edges.add((a, b))
    return edges


def contours(occupied):
    edges = boundary(occupied)
    outgoing = defaultdict(set)
    for a, b in edges:
        outgoing[a].add(b)
    directions = {(0, 1): 0, (1, 0): 1, (0, -1): 2, (-1, 0): 3}
    result = []
    def append_simple(points):
        seen = {}
        for i, p in enumerate(points):
            if p in seen:
                j = seen[p]
                append_simple(points[j:i])
                append_simple(points[:j] + points[i:])
                return
            seen[p] = i
        reduced = [p for i, p in enumerate(points)
                   if (p[0] - points[i-1][0]) * (points[(i+1) % len(points)][1] - p[1])
                   != (p[1] - points[i-1][1]) * (points[(i+1) % len(points)][0] - p[0])]
        assert len(reduced) >= 4 and len(set(reduced)) == len(reduced), "invalid contour"
        result.append(reduced)
    while edges:
        start, nxt = min(edges)
        points = [start]
        a, b = start, nxt
        while True:
            edges.remove((a, b))
            outgoing[a].remove(b)
            if b == start:
                break
            points.append(b)
            d = directions[(b[0] - a[0], b[1] - a[1])]
            candidates = outgoing[b]
            assert candidates, "open contour"
            # At diagonal contacts keep separate boundaries: right, straight, left.
            def priority(c):
                nd = directions[(c[0] - b[0], c[1] - b[1])]
                return {1: 0, 0: 1, 3: 2, 2: 3}[(nd - d) % 4]
            a, b = b, min(candidates, key=priority)
        # Split point contacts, then remove only collinear grid vertices.
        append_simple(points)
    return result


def serialized_contours(font, name):
    glyph = font["glyf"][name]
    if glyph.numberOfContours == 0:
        return []
    assert glyph.numberOfContours > 0, "unexpected composite"
    coordinates, ends, flags = glyph.getCoordinates(font["glyf"])
    assert all(flag & 1 for flag in flags), "curve in pixel font"
    result, start = [], 0
    for end in ends:
        points = []
        for x, y in coordinates[start:end+1]:
            assert x % PIXEL == 0 and y % PIXEL == 0, "non-grid vertex"
            points.append((x // PIXEL, y // PIXEL))
        assert len(points) >= 4 and len(points) == len(set(points)), "invalid serialized contour"
        result.append(points)
        start = end + 1
    return result


def expanded_edges(polygons):
    result = set()
    for points in polygons:
        for a, b in zip(points, points[1:] + points[:1]):
            dx, dy = b[0] - a[0], b[1] - a[1]
            assert (dx == 0) != (dy == 0), "non-orthogonal edge"
            step = (0 if dx == 0 else (1 if dx > 0 else -1),
                    0 if dy == 0 else (1 if dy > 0 else -1))
            for i in range(abs(dx) + abs(dy)):
                p = (a[0] + i * step[0], a[1] + i * step[1])
                q = (p[0] + step[0], p[1] + step[1])
                assert (p, q) not in result, "duplicate edge"
                result.add((p, q))
    return result


def winding(polygons, x, y):
    count = 0
    for points in polygons:
        for a, b in zip(points, points[1:] + points[:1]):
            if a[0] == b[0] and a[0] > x:
                if a[1] <= y < b[1]:
                    count += 1
                elif b[1] <= y < a[1]:
                    count -= 1
    return count != 0


def verify(path, source, mapping):
    font = TTFont(path)
    assert font.getBestCmap() == mapping, f"cmap mismatch: {path}"
    height = source["Height"] * PIXEL
    assert font["head"].unitsPerEm == height
    assert (font["hhea"].ascent, font["hhea"].descent, font["hhea"].lineGap) == (height, 0, 0)
    assert (font["OS/2"].sTypoAscender, font["OS/2"].sTypoDescender, font["OS/2"].sTypoLineGap) == (height, 0, 0)
    checked = 0
    for i, g in enumerate(source["Glyphs"]):
        name = f"g{i:03d}"
        occupied = cells(g)
        polygons = serialized_contours(font, name)
        assert expanded_edges(polygons) == boundary(occupied), f"boundary/offset mismatch: {path} {i}"
        lsb = min((x for x, _ in occupied), default=g["Offset"][0]) * PIXEL
        assert font["hmtx"][name] == (g["StepX"] * PIXEL, lsb), f"metric mismatch: {path} {i}"
        ox, oy = g["Offset"]
        w, h = g["Bounds"]
        for y in range(min(0, oy)-1, max(source["Height"], oy+h)+1):
            for x in range(min(0, ox)-1, max(g["StepX"], ox+w)+1):
                assert winding(polygons, x+.5, y+.5) == ((x,y) in occupied), f"coverage mismatch: {path} {i} {x},{y}"
                checked += 1
    assert font.getGlyphOrder()[0] == ".notdef"
    assert font["hmtx"][".notdef"][0] == source["Glyphs"][32]["StepX"] * PIXEL
    font.close()
    return checked


def build(source, name, out):
    glyphs = source["Glyphs"]
    assert len(glyphs) == 256 and all(g is not None for g in glyphs), f"missing glyph: {name}"
    names = [".notdef"] + [f"g{i:03d}" for i in range(256)]
    mapping = {0xE000+i: f"g{i:03d}" for i in range(256)}
    mapping.update({i: f"g{i:03d}" for i in range(256) if i != 0xA0})
    mapping.update({cp: f"g{i:03d}" for cp, i in ALIASES.items()})
    fb = FontBuilder(source["Height"] * PIXEL, isTTF=True)
    fb.setupGlyphOrder(names)
    fb.setupCharacterMap(mapping)
    outlines, metrics = {}, {}
    all_cells = set()
    for i, g in enumerate(glyphs):
        occupied = cells(g)
        all_cells.update(occupied)
        pen = TTGlyphPen(None)
        for polygon in contours(occupied):
            pen.moveTo(tuple(v * PIXEL for v in polygon[0]))
            for p in polygon[1:]:
                pen.lineTo(tuple(v * PIXEL for v in p))
            pen.closePath()
        gn = f"g{i:03d}"
        outlines[gn] = pen.glyph()
        metrics[gn] = (g["StepX"] * PIXEL,
                       min((x for x, _ in occupied), default=g["Offset"][0]) * PIXEL)
    # Deliberate visible missing-character box, never an invented source glyph.
    step = glyphs[32]["StepX"]
    pen = TTGlyphPen(None)
    missing = {(x,y) for x in range(max(1,step-1)) for y in range(source["Height"])
               if x in (0,step-2) or y in (0,source["Height"]-1)}
    for polygon in contours(missing):
        pen.moveTo(tuple(v*PIXEL for v in polygon[0]))
        for p in polygon[1:]:
            pen.lineTo(tuple(v*PIXEL for v in p))
        pen.closePath()
    outlines[".notdef"] = pen.glyph()
    metrics[".notdef"] = (step*PIXEL,0)
    fb.setupGlyf(outlines)
    fb.setupHorizontalMetrics(metrics)
    height = source["Height"] * PIXEL
    fb.setupHorizontalHeader(ascent=height, descent=0, lineGap=0)
    outline = "Outline" in name
    assert "SetBSize" in name, "only ARTS is supported"
    family = "ARTS"
    size = int(name[-1])
    stem = f"stars{'-outline' if outline else ''}-{size}"
    css_family = f"STARS{' Outline' if outline else ''} {size}"
    fb.setupNameTable({"familyName": css_family, "styleName": "Regular",
                      "uniqueFontIdentifier": f"ATC-SIM:{COMMIT}:{name}",
                      "fullName": css_family, "psName": stem,
                      "version": "Version 1.000", "copyright": COPYRIGHT,
                      "description": "Fonts converted from Vice's STARS bitmaps. Source: " + name,
                      "licenseDescription": LICENSE,
                      "licenseInfoURL": "https://www.gnu.org/licenses/gpl-3.0.html"})
    fb.setupOS2(version=4, sTypoAscender=height, sTypoDescender=0, sTypoLineGap=0,
               usWinAscent=max(height, max((y+1)*PIXEL for _,y in all_cells)),
               usWinDescent=max(0, -min(y*PIXEL for _,y in all_cells)), fsType=0, fsSelection=0xC0)
    fb.setupPost()
    fb.setupMaxp()
    fb.font["head"].created = fb.font["head"].modified = 3874262400  # 2026-10-08 UTC, deterministic
    fb.font.recalcTimestamp = False
    gasp = newTable("gasp")
    gasp.gaspRange = {65535: 0}  # No grid fitting or smoothing requested; browsers may still antialias.
    fb.font["gasp"] = gasp
    ttf = out / (stem + ".ttf")
    fb.save(ttf)
    fb.font.flavor = "woff2"
    fb.save(out / (stem + ".woff2"))
    checked = sum(verify(out/(stem+ext), source, mapping) for ext in (".ttf", ".woff2"))
    return {"source": name, "family": family.lower(), "outline": outline, "size": size,
            "height": source["Height"], "width": source["Width"], "cssFamily": css_family,
            "stem": stem, "glyphs": len(glyphs), "verifiedPixelSamples": checked,
            "advances": [g["StepX"] for g in glyphs]}


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("json", type=Path)
    parser.add_argument("output", type=Path)
    args = parser.parse_args()
    fonts = json.loads(args.json.read_text())
    assert len(fonts) == 12, "missing authored ARTS face"
    args.output.mkdir(parents=True, exist_ok=True)
    assets = [build(f, n, args.output) for n, f in sorted(fonts.items())]
    manifest = {"commit": COMMIT, "unitsPerPixel": PIXEL, "copyright": COPYRIGHT,
                "license": "GPL-3.0-only", "aliases": {str(k):v for k,v in ALIASES.items()}, "assets": assets}
    (args.output / "manifest.json").write_text(json.dumps(manifest, indent=2) + "\n")
    css = "/* Fonts converted from Vice's STARS bitmaps; GPL-3.0-only. */\n"
    specimens = []
    for asset in assets:
        family, stem, h = asset["cssFamily"], asset["stem"], asset["height"]
        css += f'@font-face {{ font-family: "{family}"; src: url("{stem}.woff2") format("woff2"), url("{stem}.ttf") format("truetype"); font-weight: 400; font-style: normal; font-display: block; }}\n'
        symbols = "Δ ∆ ▲ ▼ □ " + " ".join(chr(0xE000+i) for i in range(128,160))
        # Browser font text beside independently drawn source cells, at native scale.
        samples = "ABCDEFGHIJKLMNOPQRSTUVWXYZ 0123456789 .,:;!?+-*/()[] " + symbols
        rectangles, advance = [], 0
        for ch in samples:
            cp = ord(ch)
            index = ALIASES.get(cp, cp-0xE000 if 0xE000 <= cp <= 0xE0FF else cp)
            g = fonts[asset["source"]]["Glyphs"][index]
            for x,y in cells(g):
                rectangles.append(f'<rect x="{advance+x}" y="{h-y-1}" width="1" height="1"/>')
            advance += g["StepX"]
        specimens.append(f'<section data-stem="{stem}"><h2>{family}: {h}px</h2><!-- prettier-ignore --><div class="sample" style=\'font-family:"{family}";font-size:{h}px;line-height:{h}px\'>{escape(samples)}</div><!-- prettier-ignore --><svg width="{advance}" height="{h}" aria-label="Source bitmap reference" shape-rendering="crispEdges">{"".join(rectangles)}</svg></section>')
    (args.output / "fonts.css").write_text(css)
    (args.output / "specimen.html").write_text('<!doctype html><html lang="en"><meta charset="utf-8"><title>STARS font specimen</title><link rel="stylesheet" href="fonts.css"><style>body{background:#000;color:#0f0;font:12px monospace}section{margin:24px 0}h2{font:12px monospace;color:#ddd}.sample{white-space:pre;font-synthesis:none;letter-spacing:0}svg{display:block;fill:#0f0}</style><h1>STARS bitmap fonts</h1><p>Browser font followed by source bitmap reference. Native authored sizes. GPL-3.0-only.</p>' + ''.join(specimens) + '<script>document.fonts.ready.then(()=>document.documentElement.dataset.fontsReady="true")</script></html>\n')
    print(f"Verified {len(assets)} faces, {sum(a['glyphs'] for a in assets)} glyphs, "
          f"{sum(a['verifiedPixelSamples'] for a in assets):,} grid samples across TTF and WOFF2.")


if __name__ == "__main__":
    main()
