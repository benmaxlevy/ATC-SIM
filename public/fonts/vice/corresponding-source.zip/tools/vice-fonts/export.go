// Export Vice's authored bitmap literals without importing its renderer.
// This parser uses only the Go standard library and rejects unknown AST forms.
package main

import (
	"encoding/json"
	"fmt"
	"go/ast"
	"go/parser"
	"go/token"
	"os"
	"strconv"
	"strings"
)

func value(e ast.Expr) any {
	switch n := e.(type) {
	case *ast.BasicLit:
		if n.Kind == token.STRING {
			s, err := strconv.Unquote(n.Value)
			if err != nil {
				panic(err)
			}
			return s
		}
		i, err := strconv.ParseInt(n.Value, 0, 64)
		if err != nil {
			panic(err)
		}
		return i
	case *ast.UnaryExpr:
		if n.Op == token.SUB {
			return -value(n.X).(int64)
		}
	case *ast.CompositeLit:
		if _, ok := n.Type.(*ast.MapType); ok {
			m := map[string]any{}
			for _, el := range n.Elts {
				kv := el.(*ast.KeyValueExpr)
				k := value(kv.Key).(string)
				if _, exists := m[k]; exists {
					panic("duplicate map key")
				}
				m[k] = value(kv.Value)
			}
			return m
		}
		if len(n.Elts) > 0 {
			if kv, ok := n.Elts[0].(*ast.KeyValueExpr); ok {
				if _, ok := kv.Key.(*ast.Ident); ok {
					m := map[string]any{}
					for _, el := range n.Elts {
						kv := el.(*ast.KeyValueExpr)
						k := kv.Key.(*ast.Ident).Name
						if _, exists := m[k]; exists {
							panic("duplicate field")
						}
						m[k] = value(kv.Value)
					}
					return m
				}
			}
		}
		a := []any{}
		next := 0
		seen := map[int]bool{}
		for _, el := range n.Elts {
			if kv, ok := el.(*ast.KeyValueExpr); ok {
				next = int(value(kv.Key).(int64))
				el = kv.Value
			}
			if next < 0 || seen[next] {
				panic("invalid or duplicate array index")
			}
			seen[next] = true
			for len(a) <= next {
				a = append(a, nil)
			}
			a[next] = value(el)
			next++
		}
		return a
	}
	panic(fmt.Sprintf("unsupported AST form %T", e))
}

func main() {
	if len(os.Args) != 2 {
		panic("usage: exporter font-bitmaps.go")
	}
	f, err := parser.ParseFile(token.NewFileSet(), os.Args[1], nil, 0)
	if err != nil {
		panic(err)
	}
	for _, d := range f.Decls {
		g, ok := d.(*ast.GenDecl)
		if !ok {
			continue
		}
		for _, s := range g.Specs {
			v, ok := s.(*ast.ValueSpec)
			if !ok {
				continue
			}
			for i, name := range v.Names {
				if name.Name == "starsFonts" {
					enc := json.NewEncoder(os.Stdout)
					enc.SetIndent("", "  ")
					fonts := value(v.Values[i]).(map[string]any)
					for name := range fonts {
						if !strings.Contains(name, "SetBSize") {
							delete(fonts, name)
						}
					}
					if len(fonts) != 12 {
						panic("missing ARTS face")
					}
					if err := enc.Encode(fonts); err != nil {
						panic(err)
					}
					return
				}
			}
		}
	}
	panic("starsFonts declaration missing")
}
