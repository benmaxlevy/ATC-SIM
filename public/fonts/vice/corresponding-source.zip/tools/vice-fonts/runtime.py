#!/usr/bin/env python3
"""Generate the small browser metric catalog from verified converter output."""
import json
import sys
from pathlib import Path

root = Path(sys.argv[1]) if len(sys.argv) > 1 else Path(__file__).resolve().parents[2]
(root / "src/scope").mkdir(parents=True, exist_ok=True)
manifest = json.loads((root / "public/fonts/vice/manifest.json").read_text())
fonts = json.loads((Path(sys.argv[2]) if len(sys.argv) > 2 else root / "tools/vice-fonts/source/bitmaps.json").read_text())
assets = []
for a in manifest["assets"]:
    if a["outline"]:
        continue
    glyphs = fonts[a["source"]]["Glyphs"]
    ink = []
    for g in glyphs:
        w,h = g["Bounds"]
        ox,oy = g["Offset"]
        points = [(ox+x,oy+h-y-1) for y,row in enumerate(g["Bitmap"]) for x in range(w) if row & (1 << (31-x))]
        ink.append([min(x for x,y in points), min(y for x,y in points), max(x for x,y in points)+1, max(y for x,y in points)+1] if points else None)
    assets.append({k:a[k] for k in ("family", "size", "height", "width", "cssFamily", "stem", "advances")} | {"ink":ink})
# JSON is kept as data; TypeScript imports it through fonts.ts.
(root / "src/scope/viceFontMetrics.json").write_text(json.dumps(assets, indent=2) + "\n")

css = (root / "public/fonts/vice/fonts.css").read_text()
for a in manifest["assets"]:
    for ext in (".ttf", ".woff2"):
        css = css.replace('url("' + a["stem"] + ext + '")', 'url("/fonts/vice/' + a["stem"] + ext + '")')
css += """
/* Native glyph advances: no synthetic weight, letter spacing, or condensed caps. */
.dcb .dcb-cell { font-weight: 400; font-synthesis: none; letter-spacing: 0; }
.dcb .dcb-main-grid[data-dcb-layout="MAIN"] {
  grid-template-columns: repeat(8, var(--dcb-column, 72px)) repeat(6, 45px) repeat(8, var(--dcb-column, 72px));
}
.dcb .dcb-main-grid[data-dcb-layout="AUX"] { grid-template-columns: repeat(17, var(--dcb-column, 72px)); }
.dcb .dcb-main-grid[data-dcb-layout="CHAR_SIZE"] { grid-template-columns: repeat(6, var(--dcb-column, 72px)); }
"""
(root / "src/scope/viceFonts.css").write_text(css)
