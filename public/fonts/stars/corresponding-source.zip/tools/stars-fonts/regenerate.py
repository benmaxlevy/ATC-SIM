#!/usr/bin/env python3
"""Rebuild from checked-in pinned source, optionally reacquiring it from Vice."""
import argparse
import hashlib
from pathlib import Path
import subprocess
import sys
import tempfile

ROOT = Path(__file__).resolve().parents[2]
HERE = Path(__file__).resolve().parent
COMMIT = "afec9e5282d09697d542f5de1e11072206afd1db"


def run(*args, **kwargs):
    return subprocess.run(args, check=True, **kwargs)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--output-root", type=Path, default=ROOT)
    parser.add_argument("--fetch", action="store_true", help="verify vendored source against a fresh pinned Vice checkout")
    args = parser.parse_args()
    output_root = args.output_root.resolve()
    assert subprocess.check_output(["go", "version"], text=True).split()[2] == "go1.24.4", "Go 1.24.4 required"
    source = HERE / "source/font-bitmaps.go"
    expected = (HERE / "source/SHA256SUMS").read_text().split()[0]
    assert hashlib.sha256(source.read_bytes()).hexdigest() == expected, "pinned source checksum mismatch"
    with tempfile.TemporaryDirectory(prefix="atc-vice-fonts-") as work:
        work = Path(work)
        if args.fetch:
            vice = work / "vice"
            run("git", "init", "-q", str(vice))
            run("git", "-C", str(vice), "fetch", "--depth=1", "https://github.com/mmp/vice.git", COMMIT)
            fetched = subprocess.check_output(["git", "-C", str(vice), "show", "FETCH_HEAD:stars/font-bitmaps.go"])
            assert fetched == source.read_bytes(), "upstream source differs"
        env_python = work / "venv/bin/python"
        run(sys.executable, "-m", "venv", str(work / "venv"))
        run(str(env_python), "-m", "pip", "install", "--disable-pip-version-check", "-r", str(HERE / "requirements.txt"))
        exporter = work / "export"
        run("go", "build", "-o", str(exporter), str(HERE / "export.go"))
        with (HERE / "source/bitmaps.json").open("w") as output:
            run(str(exporter), str(source), stdout=output)
        run(str(env_python), str(HERE / "build.py"), str(HERE / "source/bitmaps.json"), str(output_root / "public/fonts/stars"))
        run(str(env_python), str(HERE / "runtime.py"), str(output_root), str(HERE / "source/bitmaps.json"))
        run("npx", "--no-install", "prettier", "--write",
            "src/scope/starsFontMetrics.json", "src/scope/starsFonts.css",
            "public/fonts/stars/manifest.json", "public/fonts/stars/fonts.css",
            "public/fonts/stars/specimen.html", cwd=output_root)


if __name__ == "__main__":
    main()
